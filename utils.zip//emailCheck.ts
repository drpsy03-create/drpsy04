// Утилита для проверки email конфигурации
import { emailService } from '../services/emailService';

export interface EmailCheckResult {
  isConfigured: boolean;
  canSendEmail: boolean;
  message: string;
  details: {
    serviceConfigured: boolean;
    templateConfigured: boolean;
    userConfigured: boolean;
    connectionWorking?: boolean;
  };
}

/**
 * Проверяет конфигурацию email сервиса
 */
export async function checkEmailConfiguration(): Promise<EmailCheckResult> {
  try {
    // Проверяем базовую конфигурацию
    const config = emailService.checkConfiguration();
    
    const result: EmailCheckResult = {
      isConfigured: config.isValid,
      canSendEmail: false,
      message: config.message,
      details: {
        serviceConfigured: config.details.serviceId !== 'demo',
        templateConfigured: config.details.templateId !== 'demo',
        userConfigured: config.details.userId !== 'demo'
      }
    };

    // Если конфигурация валидна, тестируем подключение
    if (config.isValid) {
      try {
        const connectionTest = await emailService.testConnection();
        result.details.connectionWorking = connectionTest.success;
        result.canSendEmail = connectionTest.success;
        
        if (connectionTest.success) {
          result.message = '✅ EmailJS полностью настроен и работает';
        } else {
          result.message = `⚠️ EmailJS настроен, но есть проблемы с подключением: ${connectionTest.error}`;
        }
      } catch (error) {
        result.details.connectionWorking = false;
        result.message = `❌ EmailJS настроен, но тест подключения не прошел: ${error}`;
      }
    }

    return result;
  } catch (error) {
    return {
      isConfigured: false,
      canSendEmail: false,
      message: `❌ Критическая ошибка при проверке конфигурации: ${error}`,
      details: {
        serviceConfigured: false,
        templateConfigured: false,
        userConfigured: false,
        connectionWorking: false
      }
    };
  }
}

/**
 * Возвращает инструкции по настройке в зависимости от статуса
 */
export function getEmailSetupInstructions(checkResult: EmailCheckResult): string[] {
  const instructions: string[] = [];

  if (!checkResult.details.serviceConfigured) {
    instructions.push('📧 Создайте Email Service на emailjs.com');
  }

  if (!checkResult.details.templateConfigured) {
    instructions.push('📄 Создайте Email Template с необходимыми переменными');
  }

  if (!checkResult.details.userConfigured) {
    instructions.push('🔑 Получите User ID в настройках аккаунта');
  }

  if (!checkResult.details.connectionWorking && checkResult.isConfigured) {
    instructions.push('🔧 Проверьте корректность Service ID, Template ID и User ID');
    instructions.push('🌐 Убедитесь в наличии интернет-соединения');
  }

  if (instructions.length === 0) {
    instructions.push('🎉 Email полностью настроен и готов к использованию!');
  } else {
    instructions.unshift('📋 Для настройки email отправки:');
    instructions.push('📚 Подробная инструкция: /DEPLOYMENT.md');
  }

  return instructions;
}

/**
 * Логирует статус email конфигурации в консоль
 */
export async function logEmailStatus(): Promise<void> {
  try {
    const status = await checkEmailConfiguration();
    
    console.group('📧 Email Configuration Status');
    console.log('Configured:', status.isConfigured);
    console.log('Can Send:', status.canSendEmail);
    console.log('Message:', status.message);
    console.log('Details:', status.details);
    
    const instructions = getEmailSetupInstructions(status);
    if (instructions.length > 1) {
      console.group('📋 Setup Instructions:');
      instructions.forEach(instruction => console.log(instruction));
      console.groupEnd();
    }
    
    console.groupEnd();
  } catch (error) {
    console.error('❌ Failed to check email status:', error);
  }
}

// Автоматически логируем статус в dev режиме
import { getEnvironmentInfo } from './envUtils';

// Функция для инициализации проверки email в dev режиме
export function initEmailStatusCheck(): void {
  try {
    const envInfo = getEnvironmentInfo();
    if (typeof window !== 'undefined' && envInfo.dev) {
      logEmailStatus();
    }
  } catch (error) {
    console.warn('Failed to initialize email status check:', error);
  }
}